# PRINCE CLIENT — Android Launcher Prototype

This is a Kotlin + Jetpack Compose Android Studio starter project.

## Phone-only build option (GitHub Actions)
1. Create a GitHub account and a new empty repository.
2. Extract this ZIP on your phone using a file manager.
3. In the repository on github.com, choose **Add file > Upload files** and upload the extracted project contents, including the hidden `.github` folder. If your file manager hides dot-folders, enable show hidden files.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab and select **Build PRINCE CLIENT APK**.
6. Tap **Run workflow** if it has not started automatically.
7. When the run finishes, open it and download the `prince-client-debug-apk` artifact.
8. Extract the downloaded artifact ZIP; it contains `app-debug.apk`. Open it on your phone to install.

GitHub Actions builds the APK on a cloud runner, so no computer is required. Keep the repository private if you do not want the source code public.

## What works in this prototype
- Lime-green / black launcher interface
- Home, Modules and Settings tabs
- Launches the official Minecraft Bedrock Android app when installed
- Shows a clearly labelled preview catalogue

## Important technical boundary
This is a launcher, not an in-game client injection framework. Android launchers cannot independently add live FPS/CPS/coordinates, change rendering, or control Minecraft gameplay. Those features need a supported Minecraft-side API or a separately engineered, compatible integration. The preview switches in this starter are UI placeholders and do not activate gameplay modules.

## Build locally
Open this folder in Android Studio, sync Gradle, then build `assembleDebug`.

Package: `com.princeclient.launcher`
Minimum Android: 8.0 (API 26)
