package com.princeclient.launcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowOutward
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Lime = Color(0xFFB7FF00)
private val Background = Color(0xFF090D0A)
private val Panel = Color(0xFF151D16)
private val Muted = Color(0xFF9BA99B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrinceLauncherApp() }
    }
}

data class ModuleItem(val name: String, val group: String, val description: String)

@Composable
fun PrinceLauncherApp() {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf("Home") }
    var message by remember { mutableStateOf("Launcher ready") }

    val modules = listOf(
        ModuleItem("FPS display", "HUD", "Would need an in-game integration to show live FPS."),
        ModuleItem("CPS counter", "HUD", "Counts taps only when implemented with an overlay."),
        ModuleItem("Keystrokes", "HUD", "Primarily useful with a keyboard; game integration required."),
        ModuleItem("Coordinates", "HUD", "Live coordinates require access to game data."),
        ModuleItem("Armor HUD", "HUD", "Requires supported in-game data access."),
        ModuleItem("Zoom", "Visual", "A launcher cannot change the game's camera by itself."),
        ModuleItem("Fullbright", "Visual", "Requires a supported game-side implementation."),
        ModuleItem("Custom crosshair", "Visual", "Requires a supported game-side implementation."),
        ModuleItem("Waypoints", "Utility", "Can be developed as a standalone saved-location tool."),
        ModuleItem("Profiles", "Utility", "Launcher-side configuration profiles can be added.")
    )

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Lime,
            onPrimary = Color.Black,
            background = Background,
            surface = Panel,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Lime) {
                    listOf("Home", "Modules", "Settings").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = {
                                when (tab) {
                                    "Home" -> Icon(Icons.Default.SportsEsports, null)
                                    "Modules" -> Icon(Icons.Default.Extension, null)
                                    else -> Icon(Icons.Default.Settings, null)
                                }
                            },
                            label = { Text(tab) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Lime,
                                selectedTextColor = Lime,
                                indicatorColor = Lime.copy(alpha = 0.15f),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(18.dp)
            ) {
                Text("PRINCE CLIENT", color = Lime, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("BEDROCK • ANDROID LAUNCHER", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(18.dp))

                when (selectedTab) {
                    "Home" -> {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(22.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(20.dp)) {
                                Text("WELCOME BACK", color = Muted, fontSize = 12.sp, letterSpacing = 2.sp)
                                Spacer(Modifier.height(8.dp))
                                Text("Ready to play?", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                Text("Launch Minecraft Bedrock from your client hub.", color = Muted)
                                Spacer(Modifier.height(18.dp))
                                Button(
                                    onClick = {
                                        val launch = context.packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
                                        if (launch != null) {
                                            context.startActivity(launch)
                                            message = "Launching Minecraft…"
                                        } else {
                                            message = "Minecraft Bedrock was not found on this device."
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Color.Black)
                                ) {
                                    Text("LAUNCH MINECRAFT", fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.width(8.dp))
                                    Icon(Icons.Default.ArrowOutward, null)
                                }
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("CLIENT STATUS", color = Lime, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        InfoCard("Launcher", "Installed and running")
                        InfoCard("Game integration", "Not connected")
                        InfoCard("Status", message)
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Note: this is a launcher shell. It opens the official Minecraft app; it does not inject code into Minecraft or secretly modify the game.",
                            color = Muted, fontSize = 12.sp
                        )
                    }
                    "Modules" -> {
                        Text("MODULE CATALOGUE", color = Lime, fontWeight = FontWeight.Bold)
                        Text("Preview switches only — not active in-game modules yet.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(10.dp))
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(modules) { module ->
                                var enabled by remember { mutableStateOf(false) }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Panel),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(module.group.uppercase(), color = Lime, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        Spacer(Modifier.height(4.dp))
                                        Text(module.name, color = Color.White, fontWeight = FontWeight.Bold)
                                        Text(module.description, color = Muted, fontSize = 10.sp, minLines = 3)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("Preview", color = Muted, fontSize = 11.sp)
                                            Spacer(Modifier.weight(1f))
                                            Switch(
                                                checked = enabled,
                                                onCheckedChange = { enabled = it },
                                                colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = Lime)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Text("SETTINGS", color = Lime, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        InfoCard("Theme", "Neon lime + black")
                        InfoCard("Game package", "com.mojang.minecraftpe")
                        InfoCard("Build", "Prototype 0.1.0")
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.minecraft.net/"))
                                context.startActivity(intent)
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Lime)
                        ) { Text("Minecraft information") }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoCard(title: String, value: String) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Muted, fontSize = 11.sp)
            Text(value, color = Color.White, fontWeight = FontWeight.SemiBold)
        }
    }
}
